| `Version` | `Update Notes`                                                                 |
|-----------|--------------------------------------------------------------------------------|
| 1.0.1     | - Update some internal code to be a little less iffy, and a little more spiffy |
| 1.0.0     | - Initial Release                                                              |