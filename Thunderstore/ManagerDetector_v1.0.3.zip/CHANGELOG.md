| `Version` | `Update Notes`                                                                 |
|-----------|--------------------------------------------------------------------------------|
| 1.0.3     | - Fix logging to disk to not require double logs in the console.               |
| 1.0.2     | - Add logging to disk, per request. Sadly, this makes duplicate logs           |
| 1.0.1     | - Update some internal code to be a little less iffy, and a little more spiffy |
| 1.0.0     | - Initial Release                                                              |