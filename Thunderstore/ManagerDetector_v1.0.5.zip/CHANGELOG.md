| `Version` | `Update Notes`                                                                                           |
|-----------|----------------------------------------------------------------------------------------------------------|
| 1.0.5     | - Increment version for Bog Witch. Courtesy Update to make sure you know this exists and it still works. |
| 1.0.4     | - Increment version for Valheim 0.217.46. Courtesy Update.                                               |
| 1.0.3     | - Fix logging to disk to not require double logs in the console.                                         |
| 1.0.2     | - Add logging to disk, per request. Sadly, this makes duplicate logs                                     |
| 1.0.1     | - Update some internal code to be a little less iffy, and a little more spiffy                           |
| 1.0.0     | - Initial Release                                                                                        |